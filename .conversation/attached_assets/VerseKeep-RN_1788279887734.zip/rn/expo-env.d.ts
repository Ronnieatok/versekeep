/// <reference types="expo/types" />

// ─────────────────────────────────────────────────────────
// VerseKeep — Environment variable type declarations
// TypeScript will error on process.env.EXPO_PUBLIC_* without this
// ─────────────────────────────────────────────────────────

declare global {
  namespace NodeJS {
    interface ProcessEnv {
      // Supabase
      readonly EXPO_PUBLIC_SUPABASE_URL:      string;
      readonly EXPO_PUBLIC_SUPABASE_ANON_KEY: string;

      // API.Bible — free at scripture.api.bible
      readonly EXPO_PUBLIC_BIBLE_API_KEY:     string;

      // EAS — auto-filled by eas init
      readonly EXPO_PUBLIC_EAS_PROJECT_ID:    string;

      // Build environment
      readonly APP_ENV: 'development' | 'preview' | 'production';
    }
  }
}

export {};
