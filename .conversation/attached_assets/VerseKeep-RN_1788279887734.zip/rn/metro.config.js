const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Support .cjs files (needed by some Supabase internals)
config.resolver.sourceExts.push('cjs');

// Allow importing from the project root using @/ alias
config.resolver.extraNodeModules = {
  '@':        __dirname,
  '@lib':     `${__dirname}/lib`,
  '@constants': `${__dirname}/constants`,
  '@assets':  `${__dirname}/assets`,
};

module.exports = config;
