# VerseKeep 📖

**Your personal Bible verse journal.** Save scripture, write reflections, build tasks, set daily reminders, and track your reading streak — all in a beautifully designed offline-first Android app.

---

## Tech Stack

| Layer       | Tech                          |
|-------------|-------------------------------|
| Framework   | Expo SDK 52 + Expo Router 4   |
| Language    | TypeScript                    |
| Backend     | Supabase (Postgres + Auth)    |
| Local cache | expo-sqlite (offline-first)   |
| Push notifs | expo-notifications             |
| Fonts       | Bebas Neue · Playfair Display · DM Sans |
| Deploy      | EAS Build → Google Play Store |

---

## Project Structure

```
VerseKeep/
├── app/
│   ├── _layout.tsx          ← Root layout, auth guard, notification handler
│   ├── (auth)/
│   │   └── auth.tsx         ← Login + signup
│   ├── (tabs)/
│   │   ├── _layout.tsx      ← Bottom tab navigation
│   │   ├── index.tsx        ← Dashboard
│   │   ├── write.tsx        ← Write a verse (2-step)
│   │   ├── vault.tsx        ← Saved verses + bookmarks
│   │   ├── search.tsx       ← Bible search (API.Bible + vault search)
│   │   └── profile.tsx      ← Profile + settings
│   ├── verse/
│   │   └── [id].tsx         ← Verse detail (notes, tasks, tags)
│   └── reminders.tsx        ← Daily reminder setup
├── lib/
│   ├── supabase.ts          ← Supabase client
│   └── offline.ts           ← SQLite cache + useOfflineVerses hook
├── constants/
│   └── theme.ts             ← Brand colours (red/black/white) + fonts
├── supabase/
│   └── schema.sql           ← Full DB schema with RLS policies
├── scripts/
│   └── download-fonts.js    ← Downloads all 6 .ttf font files
├── assets/
│   ├── fonts/               ← .ttf files (run download-fonts.js)
│   ├── icon.png             ← 512×512 app icon
│   ├── adaptive-icon.png    ← 1024×1024 adaptive icon
│   ├── splash.png           ← Splash screen
│   ├── notification-icon.png← Push notification icon
│   └── favicon.png          ← Web favicon
├── app.json                 ← Expo config
├── eas.json                 ← EAS Build config
├── package.json             ← Dependencies
└── .env                     ← Secrets (never commit)
```

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Download fonts
```bash
node scripts/download-fonts.js
```

### 3. Set up environment
```bash
cp .env.example .env
```
Edit `.env` and fill in:
```
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=eyJ...
EXPO_PUBLIC_BIBLE_API_KEY=your_api_bible_key
```

### 4. Set up Supabase database
1. Go to [supabase.com](https://supabase.com) → your project
2. Click **SQL Editor** → **New Query**
3. Paste the contents of `supabase/schema.sql` → click **Run**

### 5. Run on your phone
```bash
npx expo start
```
- Install **Expo Go** on your Android phone (free, on Play Store)
- Scan the QR code in your terminal
- App loads instantly — no build needed for development

---

## Building for Play Store

### Preview build (APK — install directly on device)
```bash
eas build --platform android --profile preview
```

### Production build (AAB — for Play Store)
```bash
eas build --platform android --profile production
```

### Submit to Play Store
```bash
eas submit --platform android --profile production
```

---

## Environment Variables

| Variable | Where to get it |
|----------|----------------|
| `EXPO_PUBLIC_SUPABASE_URL` | supabase.com → project → Settings → API |
| `EXPO_PUBLIC_SUPABASE_ANON_KEY` | supabase.com → project → Settings → API |
| `EXPO_PUBLIC_BIBLE_API_KEY` | [scripture.api.bible](https://scripture.api.bible) (free) |
| `EXPO_PUBLIC_EAS_PROJECT_ID` | Run `eas init` once — auto-fills in app.json |

---

## Play Store Checklist

- [ ] `node scripts/download-fonts.js`
- [ ] Create `.env` with Supabase keys
- [ ] Run `supabase/schema.sql` in Supabase SQL Editor
- [ ] Test every screen in Expo Go on real Android
- [ ] Download app icon from `versekeep-icon-generator.html`
- [ ] Download notification icon from `versekeep-asset-generator.html`
- [ ] Generate screenshots with `versekeep-screenshot-generator.html`
- [ ] Register at [scripture.api.bible](https://scripture.api.bible) for Bible API key
- [ ] Create Google Play Console account ($25 one-time)
- [ ] Host privacy policy (`versekeep-privacy-and-listing.html`) on Vercel/Netlify
- [ ] Run production EAS build
- [ ] Upload .aab to Play Console Internal Testing
- [ ] Fill Data Safety form in Play Console
- [ ] Fill Content Rating questionnaire
- [ ] Upload screenshots to store listing
- [ ] Submit for review

---

## Brand

| Token | Value |
|-------|-------|
| Primary | `#C50022` (Strong Red) |
| Background | `#0A0A0A` (Near Black) |
| Surface | `#111111` |
| Text | `#F2EDE4` (Cream) |
| Display font | Bebas Neue |
| Body font | DM Sans |
| Verse font | Playfair Display |

---

## Contact

Ronald Atok — Nairobi, Kenya  
[hello@versekeep.app](mailto:hello@versekeep.app)

---

*Built with ❤️ in Nairobi*
