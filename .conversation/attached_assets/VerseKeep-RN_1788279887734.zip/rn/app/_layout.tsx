import { useEffect, useState, useRef } from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { Slot, router, useSegments } from 'expo-router';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import * as Notifications from 'expo-notifications';
import { supabase } from '../lib/supabase';
import { initOfflineDb, syncVersesToCache } from '../lib/offline';
import { T } from '../constants/theme';

SplashScreen.preventAutoHideAsync();

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge:  false,
  }),
});

export default function RootLayout() {
  const [authReady, setAuthReady] = useState(false);
  const [session,   setSession]   = useState<any>(null);
  const notifListener     = useRef<any>(null);
  const notifRespListener = useRef<any>(null);

  const [fontsLoaded] = useFonts({
    'BebasNeue':              require('../assets/fonts/BebasNeue-Regular.ttf'),
    'PlayfairDisplay':        require('../assets/fonts/PlayfairDisplay-Regular.ttf'),
    'PlayfairDisplay-Italic': require('../assets/fonts/PlayfairDisplay-Italic.ttf'),
    'DMSans':                 require('../assets/fonts/DMSans-Regular.ttf'),
    'DMSans-Medium':          require('../assets/fonts/DMSans-Medium.ttf'),
    'DMSans-Bold':            require('../assets/fonts/DMSans-Bold.ttf'),
  });

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      await initOfflineDb();
      if (session) syncVersesToCache().catch(() => {});
      setAuthReady(true);
    };
    init();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, newSession) => {
        setSession(newSession);
        if (newSession) syncVersesToCache().catch(() => {});
      }
    );
    return () => subscription.unsubscribe();
  }, []);

  // Notification deep-link handler
  useEffect(() => {
    notifListener.current = Notifications.addNotificationReceivedListener(
      (notification) => console.log('[VerseKeep] Notif received:', notification.request.identifier)
    );

    notifRespListener.current = Notifications.addNotificationResponseReceivedListener(
      (response) => {
        const data = response.notification.request.content.data as any;
        if (data?.verseId)         router.push({ pathname: '/verse/[id]', params: { id: data.verseId } });
        else if (data?.screen === 'reminders') router.push('/reminders');
        else                       router.replace('/(tabs)/');
      }
    );

    Notifications.getLastNotificationResponseAsync().then((response) => {
      if (!response) return;
      const data = response.notification.request.content.data as any;
      if (data?.verseId) setTimeout(() => router.push({ pathname: '/verse/[id]', params: { id: data.verseId } }), 500);
    });

    return () => {
      if (notifListener.current)     Notifications.removeNotificationSubscription(notifListener.current);
      if (notifRespListener.current) Notifications.removeNotificationSubscription(notifRespListener.current);
    };
  }, []);

  // Save Expo push token to Supabase reminders table
  useEffect(() => {
    if (!session || Platform.OS === 'web') return;
    Notifications.getPermissionsAsync().then(async ({ status }) => {
      if (status !== 'granted') return;
      try {
        const token = await Notifications.getExpoPushTokenAsync({ projectId: process.env.EXPO_PUBLIC_EAS_PROJECT_ID });
        await supabase.from('reminders').update({ expo_token: token.data }).eq('user_id', session.user.id);
      } catch (e) { console.warn('[VerseKeep] Token save failed:', e); }
    });
  }, [session]);

  useEffect(() => {
    if (fontsLoaded && authReady) SplashScreen.hideAsync();
  }, [fontsLoaded, authReady]);

  const segments = useSegments();
  useEffect(() => {
    if (!authReady || !fontsLoaded) return;
    const inAuth = segments[0] === '(auth)';
    if (!session && !inAuth)  router.replace('/(auth)/auth');
    else if (session && inAuth) router.replace('/(tabs)/');
  }, [session, authReady, fontsLoaded, segments]);

  if (!fontsLoaded || !authReady) return <View style={s.splash} />;
  return <Slot />;
}

const s = StyleSheet.create({ splash: { flex: 1, backgroundColor: T.black } });
